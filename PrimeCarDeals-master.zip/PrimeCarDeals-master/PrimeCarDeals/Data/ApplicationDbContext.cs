﻿using System.Diagnostics.Metrics;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using PrimeCarDeals.Models;

namespace PrimeCarDeals.Data
{
    public class ApplicationDbContext : IdentityDbContext<UserRegistration>
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }
        public DbSet<Sell> sells { get; set; }

        public DbSet<Requests> requests { get; set; }

        public DbSet<CarDetails> CarDetails { get; set; }

        public DbSet<CarsSold> CarsSold {  get; set; }

        public DbSet<Payment> Payments { get; set; }

        public DbSet<VerificationAppointment> VerificationAppointments { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
             
        }

    }
}
