﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace PrimeCarDeals.Data.Migrations
{
    /// <inheritdoc />
    public partial class v3 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_sells_AspNetUsers_UserId1",
                table: "sells");

            migrationBuilder.DropIndex(
                name: "IX_sells_UserId1",
                table: "sells");

            migrationBuilder.DropColumn(
                name: "UserId1",
                table: "sells");

            migrationBuilder.AlterColumn<string>(
                name: "UserId",
                table: "sells",
                type: "nvarchar(450)",
                nullable: false,
                oldClrType: typeof(int),
                oldType: "int");

            migrationBuilder.CreateIndex(
                name: "IX_sells_UserId",
                table: "sells",
                column: "UserId");

            migrationBuilder.AddForeignKey(
                name: "FK_sells_AspNetUsers_UserId",
                table: "sells",
                column: "UserId",
                principalTable: "AspNetUsers",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_sells_AspNetUsers_UserId",
                table: "sells");

            migrationBuilder.DropIndex(
                name: "IX_sells_UserId",
                table: "sells");

            migrationBuilder.AlterColumn<int>(
                name: "UserId",
                table: "sells",
                type: "int",
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(450)");

            migrationBuilder.AddColumn<string>(
                name: "UserId1",
                table: "sells",
                type: "nvarchar(450)",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_sells_UserId1",
                table: "sells",
                column: "UserId1");

            migrationBuilder.AddForeignKey(
                name: "FK_sells_AspNetUsers_UserId1",
                table: "sells",
                column: "UserId1",
                principalTable: "AspNetUsers",
                principalColumn: "Id");
        }
    }
}
