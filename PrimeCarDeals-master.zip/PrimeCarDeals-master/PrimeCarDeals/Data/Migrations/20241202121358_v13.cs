﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace PrimeCarDeals.Data.Migrations
{
    /// <inheritdoc />
    public partial class v13 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "status",
                table: "requests",
                newName: "Status");

            migrationBuilder.RenameColumn(
                name: "address",
                table: "CarDetails",
                newName: "Address");

            migrationBuilder.RenameColumn(
                name: "carId",
                table: "CarDetails",
                newName: "CarId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "Status",
                table: "requests",
                newName: "status");

            migrationBuilder.RenameColumn(
                name: "Address",
                table: "CarDetails",
                newName: "address");

            migrationBuilder.RenameColumn(
                name: "CarId",
                table: "CarDetails",
                newName: "carId");
        }
    }
}
