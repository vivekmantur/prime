﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PrimeCarDeals.Models;
using PrimeCarDeals.Repositories;

namespace PrimeCarDeals.Controllers
{
    /// <summary>
    /// Admin functionalities for handling user requests.
    /// </summary>
    [Authorize(Roles = "Admin")]
    public class AdminController : Controller
    {
        private readonly IAdminRepository _adminRepository;
        private readonly EmailService _emailService;

        public AdminController(IAdminRepository adminRepository, EmailService emailService)
        {
            _adminRepository = adminRepository;
            _emailService = emailService;
        }

        /// <summary>
        /// Action to display all pending requests.
        /// </summary>
        /// <returns>List of pending requests.</returns>
        public IActionResult Index()
        {
            List<Requests> pendingRequests = _adminRepository.GetRequestsByFilter(r => r.Status == "Pending");
            return View(pendingRequests);
        }

        /// <summary>
        /// Action to display request details.
        /// </summary>
        /// <param name="id">Request ID</param>
        /// <returns>Request details view.</returns>
        public IActionResult Details(int id)
        {
            Requests? request = _adminRepository.GetRequestById(id);

            if (request == null)
                return NotFound();

            ViewBag.FrontImage = request.Sell.FrontImage;
            ViewBag.RearImage = request.Sell.RearImage;
            ViewBag.LeftImage = request.Sell.LeftImage;
            ViewBag.RightImage = request.Sell.RightImage;

            return View(request);
        }

        /// <summary>
        /// Action to reject a request.
        /// </summary>
        /// <param name="id">Request ID</param>
        /// <param name="reason">Rejection reason</param>
        /// <returns>Redirect to pending requests view.</returns>
        public IActionResult Reject(int id, string reason)
        {
            Requests? request = _adminRepository.GetRequestById(id);
            if (request == null)
                return NotFound();

            UserRegistration? user = _adminRepository.GetUserById(request.Userid);
            if (user == null)
                return NotFound("User not found.");

            _adminRepository.UpdateRequestStatus(id, "Rejected");

            string subject = "Your Car Request Has Been Rejected";
            string message = $@"
                Dear {user.UserName},

                We regret to inform you that your car request has been rejected for the following reason:

                {reason}

                Thank you for your understanding.

                Regards,
                PrimeCarDeals Team
            ";
            _emailService.SendEmailAsync(user.Email, subject, message);

            return RedirectToAction(nameof(Index));
        }

        /// <summary>
        /// Approve a request, schedule verification, and notify the user.
        /// </summary>
        /// <param name="id">Request ID</param>
        /// <returns>Redirect to pending requests view.</returns>
        [HttpPost]
        public IActionResult Approve(int id)
        {
            Requests? request = _adminRepository.GetRequestById(id);
            if (request == null)
                return NotFound();

            _adminRepository.UpdateRequestStatus(id, "Under Verification");

            UserRegistration? user = _adminRepository.GetUserById(request.Userid);
            if (user != null)
            {
                string subject = "Your Car Request Has Been Approved for Verification";
                DateTime appointmentDate = DateTime.Now.AddDays(2);
                string message = $@"
                    Dear {user.UserName},

                    Congratulations! Your car request has been approved for verification.

                    Your appointment for vehicle inspection is scheduled on:
                    {appointmentDate:dd/mm/yyyy}

                    Regards,
                    PrimeCarDeals Team
                ";

                _emailService.SendEmailAsync(user.Email, subject, message);
            }

            _adminRepository.ScheduleVerificationAppointment(id, DateTime.Now.AddDays(2));
            return RedirectToAction(nameof(Index));
        }

        /// <summary>
        /// Action to approve verification and add car details.
        /// </summary>
        /// <param name="id">Verification ID</param>
        /// <returns>Redirect to approved requests view.</returns>
        public IActionResult ApproveVerification(int id)
        {
            VerificationAppointment? verification = _adminRepository.GetVerificationAppointmentById(id);
            if (verification == null)
                return NotFound();

            _adminRepository.VerifyRequest(verification.RequestId);

            Sell? sellDetails = _adminRepository.GetSellDetailsByRequestId(verification.Request.Sellid);
            if (sellDetails != null)

                _adminRepository.AddCarDetails(sellDetails);

            return RedirectToAction(nameof(RequestApproved));
        }

        /// <summary>
        /// Action to view approved requests.
        /// </summary>
        /// <returns>Approved requests view.</returns>
        public IActionResult RequestApproved()
        {
            List<Requests> requests = _adminRepository.GetApprovedRequests();
            requests = _adminRepository.SortBy(requests, r => r.Price);
            return View(requests);
        }

        /// <summary>
        /// Action to download PDF of a request.
        /// </summary>
        /// <param name="id">Request ID</param>
        /// <returns>PDF file.</returns>
        public IActionResult DownloadPdf(int id)
        {
            Requests? request = _adminRepository.GetRequestById(id);
            if (request != null && request.Sell?.Documents != null)
            {
                return File(request.Sell.Documents, "application/pdf", "DocumentsFile.pdf");
            }
            return NotFound();
        }

        /// <summary>
        /// Action to list rejected requests.
        /// </summary>
        /// <returns>Rejected requests view.</returns>
        public IActionResult RejectedStatus()
        {
            //List<Requests> requests = _adminRepository.GetRejectedRequests();
            List<Requests> requests = _adminRepository.GetRequestsByFilter(r => r.Status == "Rejected");
            return View(requests);
        }

        public IActionResult GetVerificationPending()
        {
            List<VerificationAppointment> pendingAppointments = _adminRepository.GetPendingVerificationAppointment();
            return View(pendingAppointments);
        }

        public IActionResult RejectVerification(int verificationId)
        {
            _adminRepository.RejectVerification(verificationId);
            return RedirectToAction("GetVerificationPending");
        }
    }
}