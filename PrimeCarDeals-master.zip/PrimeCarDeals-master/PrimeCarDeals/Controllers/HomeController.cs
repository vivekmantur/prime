using System.Diagnostics;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PrimeCarDeals.Data;
using PrimeCarDeals.Models;

namespace PrimeCarDeals.Controllers
{
    /// <summary>
    /// Controller which manages common pages 
    /// </summary>
    public class HomeController : Controller
    {
        public ApplicationDbContext _context;
        public HomeController(ApplicationDbContext _context)
        {
            this._context = _context; 
        }
        /// <summary>
        /// This class is used for website landing page when we open
        /// </summary>
        /// <returns></returns>
        [AllowAnonymous]
        public IActionResult Home()
        {
            List<CarDetails> unsoldCarList = _context.CarDetails.ToList();
            unsoldCarList = unsoldCarList.Where(i => i.Status == "unsold").ToList();
            return View(unsoldCarList);
        }
        /// <summary>
        /// PrimeCarDeals website detail page
        /// </summary>
        /// <returns>View for about apge</returns>
        [AllowAnonymous]
        public IActionResult About()
        {
            return View();
        }
        /// <summary>
        /// Privacy policy view
        /// </summary>
        /// <returns>View</returns>
        [HttpGet]
        public IActionResult PrivacyPolicy()
        {
            return View();
        }
        /// <summary>
        /// Terms and conditions view
        /// </summary>
        /// <returns>View</returns>
        [HttpGet]
        public IActionResult TermsConditions()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}