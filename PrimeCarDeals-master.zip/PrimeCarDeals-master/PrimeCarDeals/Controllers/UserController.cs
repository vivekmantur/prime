﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Identity;
using System.Security.Claims;
using PrimeCarDeals.Models;
using PrimeCarDeals.Repositories;
using PrimeCarDeals.ViewModel;
using Microsoft.EntityFrameworkCore;
using PrimeCarDeals.Data;
using Microsoft.AspNetCore.Authorization;

namespace PrimeCarDeals.Controllers
{
    /// <summary>
    /// User Class contain sell,buy,payment functionalities 
    /// </summary>
    [Authorize]
    public class UserController : Controller
    {
        private readonly IUserRepository _userRepository;
        public SignInManager<UserRegistration> signInManager;
        public ApplicationDbContext context;
        public UserController(IUserRepository userRepository, SignInManager<UserRegistration> signInManager,ApplicationDbContext context)
        {
            _userRepository = userRepository;
            this.signInManager = signInManager;
            this.context = context;
        }

        /// <summary>
        /// taking current time and storing it in a session
        /// </summary>
        public void UpdateLastActivityTime()
        {
            HttpContext.Session.SetString("LastActivity", DateTime.UtcNow.ToString());
        }
        /// <summary>
        /// Checking UserInactivity and logging out if he is inactive
        /// </summary>
        /// <returns></returns>
        public IActionResult CheckUserInactivity()
        {
            String? lastActivity = HttpContext.Session.GetString("LastActivity");
            if (lastActivity != null)
            {
                DateTime lastActivityTime = DateTime.Parse(lastActivity);
                if (DateTime.UtcNow.Subtract(lastActivityTime).TotalMinutes > 10)
                {
                    // User is inactive for more than 10 minutes, log them out
                    signInManager.SignOutAsync().Wait();
                    HttpContext.Session.Clear();
                    return RedirectToAction("Login", "Account");
                }
            }

            // Update the last activity time
            UpdateLastActivityTime();
            return null; // No inactivity detected, continue with the request
        }
        
        /// <summary>
        /// View to present a sell application form
        /// </summary>
        /// <returns>View that contain form to sell a car</returns>
        public IActionResult Sell()
        {
            IActionResult inactivityCheckResult = CheckUserInactivity();
            if (inactivityCheckResult != null)
            {
                return inactivityCheckResult; // If user is inactive, they'll be redirected to login
            }
            return View();
        }
        /// <summary>
        /// action method which contain Sell functionality
        /// </summary>
        /// <param name="sell">Car Details Input</param>
        /// <returns>Dashboard View</returns>
        [HttpPost]
        public IActionResult Sell(SellViewModel sell)
        {
            string? userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
            
            if (ModelState.IsValid)
            {
                if (sell.Documents != null)
                {
                   
                    var fileExtension = Path.GetExtension(sell.Documents.FileName).ToLower();

                    if (fileExtension != ".pdf")
                    {
                        ModelState.AddModelError("Documents", "Only PDF files are allowed.");
                    }
                }
                _userRepository.AddSellRequest(sell, userId);
                TempData["SuccessMessage"] = "Vehicle details have been successfully sent to Admin Please wait for approval through Mail";
                return RedirectToAction("Dashboard", "User");
            }

            return View(sell);
        }
        /// <summary>
        /// User Dashboard View which contains unsold cars
        /// </summary>
        /// <returns>View</returns>
        public IActionResult Dashboard()
        {
            IActionResult inactivityCheckResult = CheckUserInactivity();
            if (inactivityCheckResult != null)
            {
                return inactivityCheckResult; // If user is inactive, they'll be redirected to login
            }

            List<CarDetails> unsoldCarList = _userRepository.GetUnsoldCars();

            CarDashboardViewModel model = new CarDashboardViewModel
            {
                Cars = unsoldCarList,
                Filter = new CarFilterViewModel()
            };

            return View(model);
        }
        /// <summary>
        /// Action For Search Functionality
        /// </summary>
        /// <param name="searchString">CarName Input</param>
        /// <returns>View</returns>
        public async Task<IActionResult> Index(string searchString)
        {
            if (context.CarDetails == null)
            {
                return Problem("No Cars");
            }

            var cars = from m in context.CarDetails
                       select m;

            // To find cars based on searchstring
            if (!String.IsNullOrEmpty(searchString))
            {
                cars = cars.Where(s => s.CarName!.ToUpper().Contains(searchString.ToUpper()));
            }

            cars = cars.Where(i => i.Status == "unsold");
            // Create the ViewModel and populate it with the filtered cars and the search filter
            CarDashboardViewModel model = new CarDashboardViewModel
            {
                Cars = await cars.ToListAsync(),
                Filter = new CarFilterViewModel()
            };
            return View("Dashboard", model);
        }
        /// <summary>
        /// Filtering Functionality upon user selection
        /// </summary>
        /// <param name="filter">Input Fields to filter</param>
        /// <returns>Dashboard Action View</returns>
        [HttpPost]
        public IActionResult FilterCars(CarFilterViewModel filter)
        {
            List<CarDetails> filteredCars = _userRepository.GetFilteredCars(filter);

            CarDashboardViewModel model = new CarDashboardViewModel
            {
                Cars = filteredCars,
                Filter = filter
            };
            return View("Dashboard", model);
        }
        /// <summary>
        /// Car details view
        /// </summary>
        /// <param name="id">Car Id</param>
        /// <returns>Car details View</returns>
        public IActionResult CarDetails(int id)
        {
            IActionResult inactivityCheckResult = CheckUserInactivity();
            if (inactivityCheckResult != null)
            {
                return inactivityCheckResult; // If user is inactive, they'll be redirected to login
            }
            CarDetails car = _userRepository.GetCarById(id);
            if (car == null)
            {
                return NotFound();
            }
            return View(car);
        }
        /// <summary>
        /// Action which contain car buy functionality
        /// </summary>
        /// <param name="id">Car Id input</param>
        /// <returns>Payment view</returns>
        public IActionResult Book(int id)
        {
            IActionResult inactivityCheckResult = CheckUserInactivity();
            if (inactivityCheckResult != null)
            {
                return inactivityCheckResult; // If user is inactive, they'll be redirected to login
            }
            CarDetails carDetails = _userRepository.GetCarById(id);
            return View(carDetails);
        }
        /// <summary>
        /// Action to make a payment
        /// </summary>
        /// <param name="id">Car Id</param>
        /// <returns>Payment view</returns>
        public IActionResult MakePayment(int id)
        {
            string? userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
            CarDetails carDetails = _userRepository.GetCarById(id);

            decimal amount = carDetails.Price + 10000;
            _userRepository.AddPayment(id, userId, amount);

            ViewBag.Total = amount;
            return View();
        }
        /// <summary>
        /// Action shows User Car Status
        /// </summary>
        /// <returns></returns>
        public IActionResult CarStatus()
        {
            IActionResult inactivityCheckResult = CheckUserInactivity();
            if (inactivityCheckResult != null)
            {
                return inactivityCheckResult; // If user is inactive, they'll be redirected to login
            }
            string? userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
            List<Requests> requests = _userRepository.GetRequests();
            requests = requests.Where(i => i.Userid == userId).ToList();
            return View(requests);
        }
        /// <summary>
        /// Action to cancel User Sell Request
        /// </summary>
        /// <param name="requestid">Request Id</param>
        /// <returns>Redirect to ActionMethod CarStatus</returns>
        public IActionResult Cancel(int requestid)
        {
            Requests? request = context.requests.FirstOrDefault(i => i.RequestId == requestid);
            if (request == null)
            {
                return NotFound(); 
            }
            Sell? sell = context.sells.FirstOrDefault(i => i.SellId == request.Sellid);
            if (sell == null)
            {
                return NotFound();
            }
            context.requests.Remove(request);
            context.sells.Remove(sell);
            context.SaveChanges();
            return RedirectToAction("CarStatus");
        }
       
        
    }
}