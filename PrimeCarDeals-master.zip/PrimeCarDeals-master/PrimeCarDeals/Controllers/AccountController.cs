﻿using System.Collections.Concurrent;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using PrimeCarDeals.Data;
using PrimeCarDeals.Models;
using PrimeCarDeals.ViewModel;

namespace PrimeCarDeals.Controllers
{
    /// <summary>
    /// Account controller has user profile managements functions 
    /// </summary>
    public class AccountController : Controller
    {
        private UserManager<UserRegistration> userManager;
        private SignInManager<UserRegistration> signInManager;
        public ApplicationDbContext context;
        private static readonly ConcurrentDictionary<string, (string Otp, DateTime Expiration)> otps = new();
        public EmailService emailService;
        public AccountController(UserManager<UserRegistration> userManager,
            SignInManager<UserRegistration> signInManager, ApplicationDbContext context, EmailService emailService)
        {
            this.userManager = userManager;
            this.signInManager = signInManager;
            this.context = context;
            this.emailService = emailService;
        }
       
        ///// <summary>
        ///// This class is used for website landing page when we open
        ///// </summary>
        ///// <returns></returns>
        //[AllowAnonymous]
        //public IActionResult PrimeCarDealsLandingPage()
        //{
        //    List<CarDetails> unsoldCarList = context.CarDetails.ToList();
        //    unsoldCarList = unsoldCarList.Where(i => i.Status == "unsold").ToList();
        //    return View(unsoldCarList);
        //}

        /// <summary>
        /// Presents a register view 
        /// </summary>
        /// <returns>Register view</returns>
        [HttpGet, AllowAnonymous]
        public IActionResult Register()
        {
            return View();
        }
        /// <summary>
        /// Handle User Registration Functionality
        /// </summary>
        /// <param name="request">UserViewModel which holds User Details</param>
        /// <returns>View based on action</returns>
        public async Task<IActionResult> Register(UserViewModel request)
        {
            if (ModelState.IsValid)
            {
                var user = new UserRegistration
                {
                    UserName = request.UserName,
                    Email = request.Email,
                    PhoneNumber = request.PhoneNumber,
                    Address = request.Address,
                };

                IdentityResult result = await userManager.CreateAsync(user, request.Password);
                IdentityResult res = await userManager.AddToRoleAsync(user, "User");
                if (result.Succeeded && res.Succeeded)
                {
                    return RedirectToAction("Login");
                }
            }
            return View(request);
        }
        /// <summary>
        /// Login view
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [AllowAnonymous]
        public IActionResult Login()
        {
            return View();
        }

        /// <summary>
        /// Handle login functionality
        /// </summary>
        /// <param name="model">User Login Details</param>
        /// <returns>View after Login based on successful authentication</returns>
        [HttpPost]
        [AllowAnonymous]
        public IActionResult Login(UserLogin model)
        {
            if (ModelState.IsValid)
            {
                var user = userManager.FindByEmailAsync(model.Email).Result;
                if (user == null)
                {
                    ModelState.AddModelError("message", "Invalid Email");
                    return View(model);
                }

                Boolean passwordCheck = userManager.CheckPasswordAsync(user, model.Password).Result;
                if (!passwordCheck)
                {
                    ModelState.AddModelError("message", "Invalid Password");
                    return View(model);
                }

                var result = signInManager.PasswordSignInAsync(user, model.Password, false, true).Result;
                if (result.Succeeded)
                {
                    return RedirectToAction("Dashboard", "User");
                }
                else
                {
                    ModelState.AddModelError("message", "Invalid login attempt");
                    return View(model);
                }
            }
            return View(model);
        }
        /// <summary>
        /// Logout functionality
        /// </summary>
        /// <returns>login view </returns>
        [HttpGet]
        public IActionResult Logout()
        {
            signInManager.SignOutAsync();
            return RedirectToAction("Home", "Home");
        }

        /// <summary>
        /// Profile status
        /// </summary>
        /// <param name="email">User Email</param>
        /// <returns>Profile details view</returns>
        [HttpGet]
        [Authorize(Roles = "Admin,User")]
        public IActionResult ViewProfile(string email)
        {
            UserRegistration? user = userManager.FindByEmailAsync(email).Result;

            if (user == null)
            {
                return NotFound();
            }

            //getting any payments for cars buyed for user
            List<Payment> payments = context.Payments.ToList();
            payments = payments.Where(i => i.BuyyerId == user.Id).ToList();

            //getting details of cars if user has sold recently
            List<CarsSold> carsSold = context.CarsSold.ToList();
            carsSold = carsSold.Where(i => i.UserId == user.Id).ToList();

            UserViewModel userModel = new UserViewModel
            {
                UserName = user.UserName,
                Email = user.Email,
                PhoneNumber = user.PhoneNumber,
                Address = user.Address,
            };

            ViewBag.carbuys = payments;

            ViewBag.carsold = carsSold;

            return View(userModel);
        }

        /// <summary>
        /// Profile Edit Details requirement view
        /// </summary>
        /// <returns>Profile edit view</returns>
        [HttpGet]
        [Authorize(Roles = "Admin,User")]
        public IActionResult EditProfile()
        {

            UserRegistration? user = userManager.GetUserAsync(User).Result;

            if (user == null)
            {
                return NotFound();
            }


            UserViewModel userViewModel = new UserViewModel
            {
                UserName = user.UserName,
                Email = user.Email,
                Address = user.Address,
                PhoneNumber = user.PhoneNumber
            };

            return View(userViewModel);
        }
        /// <summary>
        /// Profile edit functionality
        /// </summary>
        /// <param name="model">Profile change fields</param>
        /// <returns>Profile View</returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult EditProfile(ProfileViewModel model)
        {
            if (ModelState.IsValid)
            {

                UserRegistration? user = userManager.GetUserAsync(User).Result;

                if (user == null)
                {
                    return NotFound();
                }


                user.UserName = model.UserName;
                user.Email = model.Email;
                user.Address = model.Address;
                user.PhoneNumber = model.PhoneNumber;


                IdentityResult result = userManager.UpdateAsync(user).Result;

                if (result.Succeeded)
                {
                    return RedirectToAction("ViewProfile", new { email = user.Email });
                }
                else
                {

                    foreach (var error in result.Errors)
                    {
                        ModelState.AddModelError(string.Empty, error.Description);
                    }
                }
            }


            return View(model);
        }
        /// <summary>
        /// Change Password view 
        /// </summary>
        /// <returns>Change Password view</returns>
        [HttpGet]
        [Authorize(Roles = "Admin,User")]
        public ActionResult ChangePassword()
        {
            return View();
        }

        /// <summary>
        /// Change Password Functionality
        /// </summary>
        /// <param name="model">New Password input</param>
        /// <returns>Profile view if success else error</returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult ChangePassword(ChangePasswordViewModel model)
        {
            if (ModelState.IsValid)
            {
                // Get the current logged-in user
                UserRegistration? user = userManager.GetUserAsync(User).Result;

                if (user == null)
                {
                    return NotFound();
                }

                // Check if the current password is correct
                Boolean passwordCheckResult = userManager.CheckPasswordAsync(user, model.CurrentPassword).Result;
                if (!passwordCheckResult)
                {
                    ModelState.AddModelError(string.Empty, "The current password is incorrect.");
                    return View(model);
                }

                // Check if the new password and confirmation password match
                if (model.NewPassword != model.ConfirmPassword)
                {
                    ModelState.AddModelError(string.Empty, "The new password and confirmation password do not match.");
                    return View(model);
                }

                // Change the password
                var result = userManager.ChangePasswordAsync(user, model.CurrentPassword, model.NewPassword).Result; // Change password synchronously

                if (result.Succeeded)
                {
                    return RedirectToAction("ViewProfile", new { email = user.Email });
                }
                else
                {
                    foreach (var error in result.Errors)
                    {
                        ModelState.AddModelError(string.Empty, error.Description);
                    }
                }
            }

            return View(model);
        }

        /// <summary>
        /// Forgot Password View
        /// </summary>
        /// <returns>Post action view of Forgot Password</returns>
        [HttpGet, AllowAnonymous]
        public IActionResult ForgotPassword()
        {
            return View();
        }
        /// <summary>
        /// Forgot Password functionality through Otp
        /// </summary>
        /// <param name="model"></param>
        /// <param name="otp"></param>
        /// <returns></returns>
        [HttpPost]
        public async Task<IActionResult> ForgotPassword(ForgotPasswordViewModel model, string otp = null)
        {
            //considering tempdata checking if it doesn't contain any value we are in the first step of generating otp by email confirmation
            if (TempData["Email"] == null)
            {
                if (ModelState.IsValid)
                {
                    UserRegistration? user = await userManager.FindByEmailAsync(model.Email);
                    if (user == null)
                    {
                        ModelState.AddModelError("", "Email not found.");
                        return View();
                    }

                    // Generating OTP
                    string generatedOtp = new Random().Next(100000, 999999).ToString();
                    DateTime expiration = DateTime.UtcNow.AddMinutes(3);

                    // Storing the above generated OTP with expiration
                    otps[model.Email] = (generatedOtp, expiration);

                    // Sending OTP via emailservice
                    await emailService.SendEmailAsync(model.Email, "Password Reset OTP", $"Your OTP is {generatedOtp}. It will expire in 3 minutes.");
                    //updating tempdata that completed otp sent to email
                    TempData["Email"] = model.Email;
                    TempData.Keep("Email");
                    return View();
                }
            }
            else
            {
                // Email already provided, validate OTP
                string email = TempData["Email"].ToString();
                TempData.Keep("Email");

                if (string.IsNullOrEmpty(otp))
                {
                    ModelState.AddModelError("", "Please enter the OTP.");
                    return View();
                }

                // Check if OTP is valid and not expired
                if (otps.TryGetValue(email, out var otpDetails))
                {
                    //verifying entered otp and generated otp is same or not and otp is not expired 
                    if (otpDetails.Otp == otp && otpDetails.Expiration > DateTime.UtcNow)
                    {
                        // OTP verified, remove from store
                        otps.TryRemove(email, out _);

                        // Redirect to reset password
                        TempData["Email"] = email;
                        return RedirectToAction("ResetPassword");
                    }
                }

                ModelState.AddModelError("", "Invalid or expired OTP.");
            }

            return View();
        }
        /// <summary>
        /// Reset Password view
        /// </summary>
        /// <returns>reset password functionality view</returns>
        [HttpGet]
        public IActionResult ResetPassword()
        {
            if (TempData["Email"] == null)
                return RedirectToAction("ForgotPassword");

            TempData.Keep("Email");
            return View();
        }
        /// <summary>
        /// Reset Password after successful verification of otp
        /// </summary>
        /// <param name="model">Password change fields</param>
        /// <returns>Login view upon successful reset of password</returns>
        [HttpPost]
        public async Task<IActionResult> ResetPassword(ResetPasswordViewModel model)
        {
            if (TempData["Email"] == null)
                return RedirectToAction("ForgotPassword");

            string? email = TempData["Email"].ToString();

            if (ModelState.IsValid && model.Password == model.ConfirmPassword)
            {
                UserRegistration? user = await userManager.FindByEmailAsync(email);
                if (user == null)
                {
                    ModelState.AddModelError("", "Invalid email.");
                    return View(model);
                }

                // Reset the password
                IdentityResult resetResult = await userManager.RemovePasswordAsync(user);
                if (resetResult.Succeeded)
                {
                    await userManager.AddPasswordAsync(user, model.Password);
                    return RedirectToAction("Login");
                }

                foreach (var error in resetResult.Errors)
                {
                    ModelState.AddModelError("", error.Description);
                }
            }

            return View(model);
        }
        /// <summary>
        /// Action method is usefull for custom error message handler
        /// </summary>
        /// <param name="statusCode">Status code</param>
        /// <returns>Error View</returns>
        [Route("Error/{statusCode}")]
        public IActionResult HttpStatusCodeHandler(int statusCode)
        {
            switch (statusCode)
            {
                case 404:
                    ViewBag.ErrorMessage = "Sorry, the resource you requested could not be found";
                    break;
                case 503:
                    ViewBag.ErrorMessage = "Sorry Website is Under Maintainence";
                    break;
            }
            return View("NotFound");
        }
       
    }
}