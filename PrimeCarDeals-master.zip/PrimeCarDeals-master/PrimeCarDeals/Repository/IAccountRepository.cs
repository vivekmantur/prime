﻿namespace PrimeCarDeals.Repository
{
    public interface IAccountRepository
    {
    }
}
