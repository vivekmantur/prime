﻿using System.Reflection.Metadata;
using System.Security.Claims;
using Azure.Core;
using Microsoft.EntityFrameworkCore;
using Microsoft.Identity.Client;
using PrimeCarDeals.Data;
using PrimeCarDeals.Models;
using PrimeCarDeals.Repositories;
using PrimeCarDeals.ViewModel;

namespace WebApplication1.Repositories
{
    /// <summary>
    /// User repository handles data fetching operations from database
    /// </summary>
    public class UserRepository : IUserRepository
    {
        private readonly ApplicationDbContext _context;
        public EmailService emailService;
        public UserRepository(ApplicationDbContext context, EmailService emailService)
        {
            _context = context;
            this.emailService = emailService;
        }
        /// <summary>
        /// To get unsold cars 
        /// </summary>
        /// <returns>List of unsold Cars</returns>
        public List<CarDetails> GetUnsoldCars()
        {
            return _context.CarDetails
                           .Where(c => c.Status == "unsold")
                           .ToList();
        }
        /// <summary>
        /// To get details of a car based on carid
        /// </summary>
        /// <param name="id">Car Id input</param>
        /// <returns></returns>
        public CarDetails GetCarById(int id)
        {
            return _context.CarDetails
                           .FirstOrDefault(c => c.CarId == id);
        }
        /// <summary>
        /// Filters Car based on user input
        /// </summary>
        /// <param name="filter"></param>
        /// <returns>List of filtered cars</returns>
        public List<CarDetails> GetFilteredCars(CarFilterViewModel filter)
        {
            IQueryable<CarDetails> query = _context.CarDetails.AsQueryable();

            if (!string.IsNullOrEmpty(filter.VehicleType))
                query = query.Where(c => c.VehicleType == filter.VehicleType);

            if (!string.IsNullOrEmpty(filter.Transmission))
                query = query.Where(c => c.Transmission == filter.Transmission);

            if (!string.IsNullOrEmpty(filter.FuelType))
                query = query.Where(c => c.FuelType == filter.FuelType);

            if (filter.Year.HasValue)
                query = query.Where(c => c.Year == filter.Year);

            if (filter.MinPrice.HasValue)
                query = query.Where(c => c.Price >= filter.MinPrice);

            if (filter.MaxPrice.HasValue)
                query = query.Where(c => c.Price <= filter.MaxPrice);

            return query.Where(c => c.Status == "unsold").ToList();
        }
        /// <summary>
        /// Handle Sell Request to sell a car
        /// </summary>
        /// <param name="sell">Car Details</param>
        /// <param name="userId">Current User Id</param>
        public void AddSellRequest(SellViewModel sell, string userId)
        {
            byte[] frontImage = ConvertFileToByteArray(sell.FrontImage);
            byte[] rearImage = ConvertFileToByteArray(sell.RearImage);
            byte[] leftImage = ConvertFileToByteArray(sell.LeftImage);
            byte[] rightImage = ConvertFileToByteArray(sell.RightImage);
            byte[] documents = ConvertFileToByteArray(sell.Documents);

            Sell newSell = new Sell
            {
                UserId = userId,
                RcNumber = sell.RcNumber,
                ChassisNumber = sell.ChassisNumber,
                Address = sell.Address,
                Brand = sell.Brand,
                Transmission = sell.Transmission,
                FuelType = sell.FuelType,
                Variant = sell.Variant,
                Price = sell.Price,
                CarName = sell.CarName,
                City = sell.City,
                OwnerName = sell.OwnerName,
                Kilometers = sell.Kilometers,
                Year = sell.Year,
                VehicleType = sell.VehicleType,
                FrontImage = frontImage,
                RearImage = rearImage,
                LeftImage = leftImage,
                RightImage = rightImage,
                Documents = documents
            };

            _context.sells.Add(newSell);
            _context.SaveChanges();

            Requests carSellRequest = new Requests
            {
                Userid = userId,
                Sellid = newSell.SellId,
                Carname = sell.CarName,
                Sellername = sell.OwnerName,
                Price = sell.Price
            };
            _context.requests.Add(carSellRequest);
            _context.SaveChanges();

            UserRegistration? user = _context.Users.FirstOrDefault(i => i.Id == newSell.UserId);


        }
        /// <summary>
        /// Handles the payment process
        /// </summary>
        /// <param name="carId">CardId</param>
        /// <param name="userId">Buyyer Id</param>
        /// <param name="amount">Amount paid</param>
        public void AddPayment(int carId, string userId, decimal amount)
        {
            CarDetails? carDetails = _context.CarDetails
                                     .FirstOrDefault(i => i.CarId == carId);

             carDetails.Status = "sold";
            _context.Update(carDetails);

            Payment payment = new Payment
            {
                CarName = carDetails.CarName,
                SellerName = carDetails.OwnerName,
                AmountPaid = amount,
                BuyyerId = userId,
                CarId = carId
            };

            _context.Payments.Add(payment);
            _context.SaveChanges();

            Payment? carPaymentId = _context.Payments
                                      .FirstOrDefault(i => i.CarId == carId);

            UserRegistration? currentUser = _context.Users
                                     .FirstOrDefault(i => i.Id == userId);

            CarsSold carsSold = new CarsSold
            {
                CarId = carDetails.CarId,
                PaymentId = carPaymentId.PaymentId,
                UserId = carDetails.UserId,
                CarName = carDetails.CarName,
                BuyerName = currentUser.UserName,
                CarType = carDetails.VehicleType,
                Price = carDetails.Price,
                SellerName = carDetails.OwnerName
            };

            _context.CarsSold.Add(carsSold);
            _context.SaveChanges();
        }
        /// <summary>
        /// Convert IformFile to ByteArray to save in database
        /// </summary>
        /// <param name="file">Input File</param>
        /// <returns>Byte Array</returns>
        private byte[] ConvertFileToByteArray(IFormFile file)
        {
            if (file == null || file.Length == 0)
                return null;

            using (MemoryStream memoryStream = new MemoryStream())
            {
                file.CopyTo(memoryStream);
                return memoryStream.ToArray();
            }
        }
        /// <summary>
        /// To Get All the Requests 
        /// </summary>
        /// <returns>List of Requests</returns>
        public List<Requests> GetRequests()
        {
            var requests = _context.requests
                                    .Include(r => r.VerificationAppointment)  // Including VerificationAppointment
                                    .Include(r => r.Sell)                    // Including Sell
                                    .ToList();
            return requests;
        }

        public List<VerificationAppointment> GetSchedules(string userId)
        {
            List<VerificationAppointment> schedules = _context.VerificationAppointments.Include(r => r.Request).ToList();
            schedules = schedules.Where(i=>i.Request.Userid == userId).ToList();

            return schedules;
        }

        public void CancelSellRequest(int requestId)
        {
            // Fetch the request to be canceled
            var request = _context.requests.FirstOrDefault(r => r.RequestId == requestId);
            if (request != null)
            {
                // Fetch the related sell record
                var sell = _context.sells.FirstOrDefault(s => s.SellId == request.Sellid);
                if (sell != null)
                {
                    // Remove the request and sell records
                    _context.requests.Remove(request);
                    _context.sells.Remove(sell);
                    _context.SaveChanges();
                }
            }
        }

    }
}