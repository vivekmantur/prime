﻿using PrimeCarDeals.Models;
using PrimeCarDeals.ViewModel;

namespace PrimeCarDeals.Repositories
{
    public interface IUserRepository
    {
        List<CarDetails> GetUnsoldCars();
        CarDetails GetCarById(int id);
        List<CarDetails> GetFilteredCars(CarFilterViewModel filter);
        void AddSellRequest(SellViewModel sell, string userId);
        void AddPayment(int carId, string userId, decimal amount);

        List<VerificationAppointment> GetSchedules(string userId);

        List<Requests> GetRequests();

        void CancelSellRequest(int requestId);
    }
}