﻿using Microsoft.EntityFrameworkCore;
using PrimeCarDeals.Data;
using PrimeCarDeals.Models;

namespace PrimeCarDeals.Repositories
{
    public class AdminRepository : IAdminRepository
    {
        private readonly ApplicationDbContext _context;
        public delegate bool RequestFilterDelegate(Requests request);
        public AdminRepository(ApplicationDbContext context)
        {
            _context = context;
        }
        /// <summary>
        /// Retrieve UserDetails Based on UserId
        /// </summary>
        /// <param name="id">Current User Id</param>
        /// <returns>User Details</returns>
        public UserRegistration? GetUserById(string id)
        {
            return _context.Users.FirstOrDefault(u => u.Id == id);
        }
        /// <summary>
        /// To get pending List of Requests
        /// </summary>
        /// <returns>List of pending requests</returns>
        public List<Requests> GetPendingRequests()
        {
            return _context.requests
                           .Where(r => r.Status == "Pending")
                           .Include(r => r.Sell)
                           .ToList();
        }
        /// <summary>
        /// To get Requests based on a status
        /// </summary>
        /// <param name="filter"></param>
        /// <returns>List of Requests based on filter</returns>
        public List<Requests> GetRequestsByFilter(Func<Requests, bool> filter)
        {
            return _context.requests
                           .Where(filter)
                           .ToList();
        }
        /// <summary>
        /// Retrieve Requests Details Based on Request Id
        /// </summary>
        /// <param name="id">Request Id</param>
        /// <returns>Requests Details</returns>
        public Requests? GetRequestById(int id)
        {
            return _context.requests
                           .Include(r => r.Sell)
                           .FirstOrDefault(r => r.RequestId == id);
        }
        /// <summary>
        /// Updating Request Status 
        /// </summary>
        /// <param name="id">Request Id</param>
        /// <param name="status">Status need to update</param>
        public void UpdateRequestStatus(int id, string status)
        {
            Requests? request = _context.requests.Find(id);
            if (request != null)
            {
                request.Status = status;
                _context.SaveChanges();
            }
        }
        /// <summary>
        /// After Approval of request creating appointment for car inspection
        /// </summary>
        /// <param name="requestId">Request Id</param>
        /// <param name="date">Car Inspection Date</param>
        public void ScheduleVerificationAppointment(int requestId, DateTime date)
        {
            var verification = new VerificationAppointment
            {
                RequestId = requestId,
                VerificationDate = DateOnly.FromDateTime(date),
                Verified = VerificationStatus.Pending
            };
            _context.VerificationAppointments.Add(verification);
            _context.SaveChanges();
        }
        /// <summary>
        /// Get VerificationAppointment details 
        /// </summary>
        /// <param name="id">VerificationAppointment Id</param>
        /// <returns></returns>
        public VerificationAppointment? GetVerificationAppointmentById(int id)
        {
            return _context.VerificationAppointments
                           .Include(v => v.Request)
                           .FirstOrDefault(v => v.VerificationId == id);
        }
        /// <summary>
        /// After Successfull car inspection need to change the status in VerificationAppointment and Requests
        /// </summary>
        /// <param name="requestId">Request Id Input</param>
        public void VerifyRequest(int requestId)
        {
            Requests? request = _context.requests.Include(r => r.Sell).FirstOrDefault(r => r.RequestId == requestId);
            if (request != null)
            {
                request.Status = "Approved";
                request.VerificationAppointment.Verified = VerificationStatus.Approved;
                _context.SaveChanges();
            }
        }
        /// <summary>
        /// Retrieving Sell details basd on SellId
        /// </summary>
        /// <param name="sellId">SellId</param>
        /// <returns>Sell details</returns>
        public Sell? GetSellDetailsByRequestId(int sellId)
        {
            return _context.sells.FirstOrDefault(s => s.SellId == sellId);
        }
        /// <summary>
        /// After successfull request approval adding cardetails to make ready to sell
        /// </summary>
        /// <param name="sellDetails">Sell model details of car</param>
        public void AddCarDetails(Sell sellDetails)
        {
            CarDetails carDetails = new CarDetails
            {
                CarName = sellDetails.CarName,
                Address = sellDetails.Address,
                Year = sellDetails.Year,
                UserId = sellDetails.UserId,
                Kilometers = sellDetails.Kilometers,
                OwnerName = sellDetails.OwnerName,
                Price = sellDetails.Price,
                City = sellDetails.City,
                Variant = sellDetails.Variant,
                FuelType = sellDetails.FuelType,
                Transmission = sellDetails.Transmission,
                VehicleType = sellDetails.VehicleType,
                FrontImage = sellDetails.FrontImage,
                RearImage = sellDetails.RearImage,
                LeftImage = sellDetails.LeftImage,
                RightImage = sellDetails.RightImage
            };
            _context.CarDetails.Add(carDetails);
            _context.SaveChanges();
        }
        /// <summary>
        /// List of Approved requests
        /// </summary>
        /// <returns>List of approved cars requests</returns>
        public List<Requests> GetApprovedRequests()
        {
            return _context.requests
                           .Where(r => r.Status == "Approved")
                           .ToList();
        }
        /// <summary>
        /// To get the rejected requests
        /// </summary>
        /// <returns>List of Rejected cars request</returns>
        public List<Requests> GetRejectedRequests()
        {
            return _context.requests
                           .Where(r => r.Status == "Rejected")
                           .ToList();
        }
        /// <summary>
        /// List of Pending Verification for Car inspection
        /// </summary>
        /// <returns>List of VerificationAppointments</returns>
        public List<VerificationAppointment> GetPendingVerificationAppointment()
        {
            List<VerificationAppointment> appointments = _context.VerificationAppointments.ToList();
            appointments = appointments.Where(i => i.Verified == VerificationStatus.Rejected).ToList();
            return appointments;
        }
        /// <summary>
        /// A generic method handle sorting the list of a entity based on lambda expression
        /// </summary>
        /// <typeparam name="T">entity type</typeparam>
        /// <typeparam name="TsortKey">lambda expression</typeparam>
        /// <param name="items">list of entity type</param>
        /// <param name="sortAttribute"></param>
        /// <returns>sorted List</returns>
        public List<T> SortBy<T, TsortKey>(List<T> items, Func<T, TsortKey> sortAttribute)
        {
            return items.OrderBy(sortAttribute).ToList();
        }

        public void RejectVerification(int verificationId)
        {
            VerificationAppointment? appointment = _context.VerificationAppointments
                .Include(r => r.Request)  
                .FirstOrDefault(r => r.VerificationId == verificationId);

            appointment.Verified = VerificationStatus.Rejected;
            appointment.Request.Status = "Rejected";

            _context.Update(appointment);
            _context.SaveChanges();
        }
    }
}