﻿using Microsoft.AspNetCore.Http.Features;
using PrimeCarDeals.Models;

namespace PrimeCarDeals.Repositories
{
    public interface IAdminRepository
    {
        List<Requests> GetPendingRequests();
        Requests? GetRequestById(int id);
        void UpdateRequestStatus(int id, string status);
        void AddCarDetails(Sell sellDetails);
        List<Requests> GetApprovedRequests();
        Sell? GetSellDetailsByRequestId(int sellId);
        UserRegistration? GetUserById(string userId);
        List<Requests> GetRejectedRequests();

        List<Requests> GetRequestsByFilter(Func<Requests, bool> filter);
        void ScheduleVerificationAppointment(int requestId, DateTime verificationDate);
        List<VerificationAppointment> GetPendingVerificationAppointment();

        VerificationAppointment? GetVerificationAppointmentById(int id);

        List<T> SortBy<T, TsortKey>(List<T> items, Func<T, TsortKey> sortAttribute);

        void VerifyRequest(int requestId);

        void RejectVerification(int verificationId);
    }
}