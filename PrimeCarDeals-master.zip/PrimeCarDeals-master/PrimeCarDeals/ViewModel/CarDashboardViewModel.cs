﻿using PrimeCarDeals.Models;

namespace PrimeCarDeals.ViewModel
{
    public class CarDashboardViewModel
    {
        public IEnumerable<CarDetails> Cars { get; set; }
        public CarFilterViewModel Filter { get; set; }
    }
}
