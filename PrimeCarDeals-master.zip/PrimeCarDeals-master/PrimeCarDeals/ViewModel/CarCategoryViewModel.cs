﻿namespace PrimeCarDeals.ViewModel
{
    public class CarCategoryViewModel
    {
        public string VehicleType { get; set; }
        public int SoldCount { get; set; }
    }
}