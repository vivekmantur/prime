﻿using System;
using System.ComponentModel.DataAnnotations;
namespace PrimeCarDeals.ViewModel
{
    public class YearValidationAttribute : ValidationAttribute
    {
        public YearValidationAttribute()
        {
            ErrorMessage = "Year must not exceed the current year.";
        }

        public override bool IsValid(object value)
        {
            if (value is int year)
            {
                return year <= DateTime.Now.Year;
            }

            return false; // Return false if the value is not an integer
        }
    }
}
