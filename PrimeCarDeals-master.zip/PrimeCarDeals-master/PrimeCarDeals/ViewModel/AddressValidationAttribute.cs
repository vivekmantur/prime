﻿using System;
using System.ComponentModel.DataAnnotations;
using System.Text.RegularExpressions;

namespace PrimeCarDeals.ViewModel
{
    public class AddressValidationAttribute : ValidationAttribute
    {
        public override bool IsValid(object value)
        {
            if (value == null)
                return false;

            string address = value.ToString();

            // Regular expression to match the format: houseNo, streetAddress, pincode, state, country
            // Example format: 123, Elm St, 123456, SomeState, SomeCountry
            var addressRegex = new Regex(@"^\d+\s.*,.*,\s*\d{6},\s*[\w\s]+,\s*[\w\s]+$");

            // If the address does not match the pattern, return false
            if (!addressRegex.IsMatch(address))
                return false;

            // Now we check if the pincode contains only digits
            string[] addressParts = address.Split(',');

            if (addressParts.Length < 5)
                return false;

            var pincode = addressParts[2].Trim();
            if (!Regex.IsMatch(pincode, @"^\d{6}$"))  // Assuming pincode is a 6-digit number
                return false;

            return true;
        }

        public override string FormatErrorMessage(string name)
        {
            return $"The address must follow the format: house number, street address, pincode (6 digits), state, country. Pincode must be numeric.";
        }
    }
}
