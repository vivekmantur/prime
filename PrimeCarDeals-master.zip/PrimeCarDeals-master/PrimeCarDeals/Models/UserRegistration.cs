﻿using Microsoft.AspNetCore.Identity;
namespace PrimeCarDeals.Models
{
    public class UserRegistration : IdentityUser
    {

        public string Address { get; set; }

        public ICollection<Sell> Sells { get; set; }

        public ICollection<CarDetails> CarDetails { get; set; }

        public ICollection<CarsSold> CarsSold { get; set; }
    }
}