﻿namespace PrimeCarDeals.Models
{
    public enum VerificationStatus
    {
        Pending=0,
        Approved=1,
        Rejected=2
    }
}
