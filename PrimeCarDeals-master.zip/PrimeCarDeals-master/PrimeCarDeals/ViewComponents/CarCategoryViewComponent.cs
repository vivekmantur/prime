﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using PrimeCarDeals.Data;
using PrimeCarDeals.ViewModel;


namespace WebApplication1.ViewComponents
{
    public class CarCategoryViewComponent : ViewComponent
    {
        private readonly ApplicationDbContext _context;

        public CarCategoryViewComponent(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<IViewComponentResult> InvokeAsync()
        {
            // Collect sold counts for each vehicle type
            var categories = new List<CarCategoryViewModel>
            {
                new CarCategoryViewModel
                {
                    VehicleType = "SUV",
                    SoldCount = await _context.CarDetails.CountAsync(car => car.VehicleType == "SUV" && car.Status=="sold")
                },
                new CarCategoryViewModel
                {
                    VehicleType = "Sedan",
                    SoldCount = await _context.CarDetails.CountAsync(car => car.VehicleType == "Sedan" && car.Status=="sold")
                },
                new CarCategoryViewModel
                {
                    VehicleType = "Hatchback",
                    SoldCount = await _context.CarDetails.CountAsync(car => car.VehicleType == "Hatchback" && car.Status=="sold")
                }
            };

            return View(categories);
        }
    }
}