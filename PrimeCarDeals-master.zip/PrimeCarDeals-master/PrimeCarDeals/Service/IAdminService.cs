﻿namespace PrimeCarDeals.Service
{
    public interface IAdminService
    {
    }
}
