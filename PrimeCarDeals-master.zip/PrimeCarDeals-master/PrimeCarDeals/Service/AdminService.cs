﻿namespace PrimeCarDeals.Service
{
    public class AdminService
    {
    }
}
