﻿using Microsoft.AspNetCore.Mvc;
using PrimeCarDeals.Models;
using PrimeCarDeals.ViewModel;

namespace PrimeCarDeals.Service
{
    public interface IUserService
    {
        //void UpdateLastActivityTime();
        //IActionResult CheckUserInactivity();
        //IActionResult SellCar(SellViewModel sell, string userId);
        //List<CarDetails> GetUnsoldCars();
        //CarDetails GetCarById(int id);
        //List<CarDetails> FilterCars(CarFilterViewModel filter);
        //void AddPayment(int carId, string userId, decimal amount);
        //List<Requests> GetUserRequests(string userId);
        //void CancelSellRequest(int requestId);
    }
}
