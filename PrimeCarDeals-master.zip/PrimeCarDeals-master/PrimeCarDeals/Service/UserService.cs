﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using PrimeCarDeals.Models;
using PrimeCarDeals.Repositories;
using PrimeCarDeals.Service;
using PrimeCarDeals.ViewModel;

namespace PrimeCarDeals.Services
{
    public class UserService : IUserService
    {
        private readonly IUserRepository _userRepository;
        private readonly SignInManager<UserRegistration> _signInManager;
        private readonly HttpContext _httpContext;

        public UserService(IUserRepository userRepository, SignInManager<UserRegistration> signInManager, IHttpContextAccessor httpContextAccessor)
        {
            _userRepository = userRepository;
            _signInManager = signInManager;
            _httpContext = httpContextAccessor.HttpContext;
        }

        //public void UpdateLastActivityTime()
        //{
        //    _httpContext.Session.SetString("LastActivity", DateTime.UtcNow.ToString());
        //}

        //public IActionResult CheckUserInactivity()
        //{
        //    string? lastActivity = _httpContext.Session.GetString("LastActivity");
        //    if (lastActivity != null)
        //    {
        //        DateTime lastActivityTime = DateTime.Parse(lastActivity);
        //        if (DateTime.UtcNow.Subtract(lastActivityTime).TotalMinutes > 10)
        //        {
        //            // User is inactive for more than 10 minutes, log them out
        //            _signInManager.SignOutAsync().Wait();
        //            _httpContext.Session.Clear();
        //            return new RedirectToActionResult("Login", "Account", null);
        //        }
        //    }

        //    // Update the last activity time
        //    UpdateLastActivityTime();
        //    return null; // No inactivity detected, continue with the request
        //}

        //public IActionResult SellCar(SellViewModel sell, string userId)
        //{
        //    if (sell.Documents != null)
        //    {
        //        var fileExtension = Path.GetExtension(sell.Documents.FileName).ToLower();
        //        if (fileExtension != ".pdf")
        //        {
        //            throw new Exception("Only PDF files are allowed.");
        //        }
        //    }

        //    _userRepository.AddSellRequest(sell, userId);
        //    return new RedirectToActionResult("Dashboard", "User", null);
        //}

        //public List<CarDetails> GetUnsoldCars()
        //{
        //    return _userRepository.GetUnsoldCars();
        //}

        //public CarDetails GetCarById(int id)
        //{
        //    return _userRepository.GetCarById(id);
        //}

        //public List<CarDetails> FilterCars(CarFilterViewModel filter)
        //{
        //    return _userRepository.GetFilteredCars(filter);
        //}

        //public void AddPayment(int carId, string userId, decimal amount)
        //{
        //    _userRepository.AddPayment(carId, userId, amount);
        //}

        //public List<Requests> GetUserRequests(string userId)
        //{
        //    return _userRepository.GetRequests().Where(r => r.Userid == userId).ToList();
        //}

        //public void CancelSellRequest(int requestId)
        //{
        //    _userRepository.CancelSellRequest(requestId);
        //}

    }
}

